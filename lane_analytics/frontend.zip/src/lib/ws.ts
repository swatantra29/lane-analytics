import { FrameMessage } from '../types';

type FrameListener = (msg: FrameMessage) => void;
type StatusListener = (status: 'connecting' | 'live' | 'disconnected') => void;

class LaneWSClient {
  private ws: WebSocket | null = null;
  private url: string;
  public status: 'connecting' | 'live' | 'disconnected' = 'disconnected';
  private frameListeners: Set<FrameListener> = new Set();
  private statusListeners: Set<StatusListener> = new Set();
  private reconnectTimeout: NodeJS.Timeout | null = null;
  private retryCount: number = 0;

  constructor(url: string) {
    this.url = url;
  }

  public connect() {
    if (this.ws?.readyState === WebSocket.OPEN) return;

    this.updateStatus('connecting');

    try {
      this.ws = new WebSocket(this.url);

      this.ws.onopen = () => {
        this.updateStatus('live');
        this.retryCount = 0; // Reset backoff on success
      };

      this.ws.onmessage = (event) => {
        try {
          const data: FrameMessage = JSON.parse(event.data);
          if (data.type === 'frame') {
            this.frameListeners.forEach((listener) => listener(data));
          }
        } catch (err) {
          console.error('Failed to parse WS message:', err);
        }
      };

      this.ws.onclose = () => {
        this.updateStatus('disconnected');
        this.scheduleReconnect();
      };

      this.ws.onerror = (err) => {
        console.error('WebSocket error:', err);
        this.ws?.close();
      };
    } catch (err) {
      console.error('Failed to create WebSocket:', err);
      this.updateStatus('disconnected');
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect() {
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
    }
    
    // Exponential backoff up to 30s
    const delay = Math.min(1000 * Math.pow(2, this.retryCount), 30000);
    this.retryCount++;

    this.reconnectTimeout = setTimeout(() => {
      this.connect();
    }, delay);
  }

  public disconnect() {
    if (this.reconnectTimeout) clearTimeout(this.reconnectTimeout);
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.updateStatus('disconnected');
  }

  private updateStatus(newStatus: 'connecting' | 'live' | 'disconnected') {
    if (this.status !== newStatus) {
      this.status = newStatus;
      this.statusListeners.forEach((listener) => listener(newStatus));
      
      // Dispatch DOM event as requested in F-04/Architecture
      const event = new CustomEvent('ws-status-change', { detail: { status: newStatus } });
      document.dispatchEvent(event);
    }
  }

  public subscribeToFrames(listener: FrameListener) {
    this.frameListeners.add(listener);
    return () => this.frameListeners.delete(listener);
  }

  public subscribeToStatus(listener: StatusListener) {
    this.statusListeners.add(listener);
    listener(this.status); // emit current synchronously
    return () => this.statusListeners.delete(listener);
  }
}

// Export singleton instance
export const wsClient = new LaneWSClient('ws://localhost:8765');
