import Header from './components/Header';
import VideoPanel from './components/VideoPanel';
import CurvatureGauge from './components/CurvatureGauge';
import OffsetTicker from './components/OffsetTicker';
import LatencySparkline from './components/LatencySparkline';
import MetricsChart from './components/MetricsChart';
import { useEffect } from 'react';
import { wsClient } from './lib/ws';

export default function App() {
  useEffect(() => {
    // Initiate connection on mount
    wsClient.connect();
    
    // Cleanup on unmount (optional for a resilient SPA, but good practice)
    return () => {
      wsClient.disconnect();
    };
  }, []);

  return (
    <div className="min-h-screen bg-bg-primary text-text-primary flex flex-col font-sans">
      <Header />
      
      <main className="flex-1 p-4 md:p-6 lg:p-8 max-w-[1600px] mx-auto w-full flex flex-col gap-6">
        
        {/* Top Grid: Video Panel and Telemetry */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Column A: Video Feed */}
          <div className="lg:col-span-2 flex flex-col">
            <VideoPanel />
          </div>
          
          {/* Column B: Telemetry Panel */}
          <div className="flex flex-col gap-6" id="telemetry-panel">
            <CurvatureGauge />
            <OffsetTicker />
            <LatencySparkline />
          </div>
          
        </div>

        {/* Bottom Section: Chart */}
        <div className="w-full">
          <MetricsChart />
        </div>
        
      </main>
    </div>
  );
}
