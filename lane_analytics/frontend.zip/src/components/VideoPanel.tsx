import { useEffect, useRef, useState } from 'react';
import { wsClient } from '../lib/ws';
import { Telemetry } from '../types';

export default function VideoPanel() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [telemetry, setTelemetry] = useState<Telemetry | null>(null);

  useEffect(() => {
    return wsClient.subscribeToFrames((msg) => {
      setTelemetry(msg.telemetry);
      
      if (!canvasRef.current) return;
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const img = new Image();
      img.onload = () => {
        // Clear canvas with dark background
        ctx.fillStyle = '#0a0a0f';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Calculate aspect ratio fit
        const canvasRatio = canvas.width / canvas.height;
        const imgRatio = img.width / img.height;
        
        let drawWidth, drawHeight, offsetX = 0, offsetY = 0;
        
        if (imgRatio > canvasRatio) {
          drawWidth = canvas.width;
          drawHeight = canvas.width / imgRatio;
          offsetY = (canvas.height - drawHeight) / 2;
        } else {
          drawHeight = canvas.height;
          drawWidth = canvas.height * imgRatio;
          offsetX = (canvas.width - drawWidth) / 2;
        }
        
        ctx.drawImage(img, offsetX, offsetY, drawWidth, drawHeight);
      };
      img.src = `data:image/jpeg;base64,${msg.jpeg_b64}`;
    });
  }, []);

  // Update canvas internal resolution when resized
  useEffect(() => {
    const handleResize = () => {
      if (canvasRef.current) {
        const parent = canvasRef.current.parentElement;
        if (parent) {
          canvasRef.current.width = parent.clientWidth;
          // Maintain a 16:9 box if possible, or fill height
          canvasRef.current.height = parent.clientHeight;
        }
      }
    };
    
    // Initial size
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="relative w-full h-[300px] lg:h-[600px] bg-bg-surface-2 rounded-radius-card overflow-hidden border border-border-subtle group" id="video-panel">
      <canvas
        id="videoCanvas"
        ref={canvasRef}
        className="w-full h-full"
      />
      
      {/* Frame Badge */}
      <div className="absolute top-4 right-4 bg-bg-surface/60 backdrop-blur-md px-3 py-1 rounded-md border border-border-subtle font-mono text-xs text-text-secondary">
        FRM: {telemetry ? telemetry.frame_id : '0000'}
      </div>

      {/* Embedded HUD Card */}
      <div className="absolute bottom-4 left-4 right-4 mx-auto max-w-lg bg-bg-surface/80 backdrop-blur-xl border border-border-subtle rounded-xl p-4 flex justify-around items-center shadow-lg transition-transform duration-200 group-hover:-translate-y-1">
        <div className="text-center">
          <div className="text-xs text-text-secondary mb-1 uppercase tracking-wider font-semibold">Curvature</div>
          <div className="font-mono text-2xl font-semibold text-text-primary">
            {telemetry ? telemetry.radius_of_curvature.toFixed(1) : '---.-'}<span className="text-sm text-text-secondary ml-1">m</span>
          </div>
        </div>
        <div className="w-px h-10 bg-border-subtle"></div>
        <div className="text-center">
          <div className="text-xs text-text-secondary mb-1 uppercase tracking-wider font-semibold">Center Offset</div>
          <div className="font-mono text-2xl font-semibold text-accent-blue">
            {telemetry ? (telemetry.center_offset > 0 ? '+' : '') + telemetry.center_offset.toFixed(2) : '-.--'}<span className="text-sm text-text-secondary ml-1">m</span>
          </div>
        </div>
      </div>
    </div>
  );
}
